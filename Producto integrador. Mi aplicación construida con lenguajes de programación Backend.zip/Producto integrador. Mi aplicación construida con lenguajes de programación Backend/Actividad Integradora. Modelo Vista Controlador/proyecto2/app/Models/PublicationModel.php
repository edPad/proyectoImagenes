<?php namespace App\Models;

use CodeIgniter\Model;

class PublicationModel extends Model //En programacion orientada a onjetos esto se le conoce como herencia
{
    protected $table = 'publication'; // corresponde a la tabla en la base de datos
    protected $allowedFields = ['content', 'user'];//los campos que  podemos modificar

    public function get($id = false)
    {
        if ($id === false)
        {
            return $this->findAll(); //Corresponde a SELECT * FROM publication
        }

        return $this->asArray()
        ->where(['id' => $id])//SELECT* FROM publication WHERE id = [el valor pasadop como parámetro]
        ->first();
    }

public function show()
{
    $db = \Config\Database::connect();
    $builder = $db->table('publication');
    $builder->select('publication.*, user.name');
    $builder->join('user', 'user.id = user');
    $builder->orderBy('id', 'DESC');
    return $builder->get()->getResultArray();
}
}