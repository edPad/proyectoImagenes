<?php
namespace App\Controllers;
use App\Models\PublicationModel;

class Publication extends BaseController
{
    public function index()
    {
        $model = new PublicationModel();
        $data['posts'] = $model->show();
        // Cargar el modelo de archivos
        $this->load->model('archivos_model');

        // Obtener todos los archivos cargados anteriormente
        $data['archivos'] = $this->archivos_model->obtener_archivos();

        // Mostrar la vista que muestra la lista de archivos y el formulario de subida
        $this->load->view('archivos/index', $data);
        echo view('header');
        echo view('publication/all', $data);
        echo view('footer');
    }



public function add()
{
    $model = new PublicationModel();

    if ($this->request->getMethod() === 'post' && $this->validate(['content' => 'required']))
    {
        $model->save(['content' => $this->request->getPost('content'), 'user' => 1]);
    }
    return redirect()->to(base_url() . 'publication');
}

public function edit($id)
{
    $model = new PublicationModel();

    if ($this->request->getMethod() === 'post' && $this -> validate(['content' => 'required']))
    {
        $model->save(['id' => $this->request->getPost('id'), 'content' => $this->request->getPost('content')]);
        return redirect()->to(base_url() . 'publication');
    }
    else{
        $data['post'] = $model->get($id);
        echo view('header');
        echo view('publication/edit', $data);
        echo view('footer');
    }
}
public function delete($id)
{
    $model = new PublicationModel();
    $model->delete($id);
    return redirect()->to(base_url() . 'publication');
}

    public function index()
    {

    }

    public function subir_archivo()
    {
        // Procesar archivo subido y guardarlo en el servidor y en la base de datos
        <h2>Subir un nuevo archivo</h2>

        <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <?php if (isset($exito)): ?>
            <p class="exito"><?php echo $exito; ?></p>
        <?php endif; ?>

        <?php echo form_open_multipart('archivos/subir'); ?>

        <label for="archivo">Archivo:</label>
        <input type="file" name="archivo" id="archivo" />

        <button type="submit">Subir archivo</button>

        <?php echo form_close(); 

    }

    public function ver_archivo($id)
{
    // Obtener información del archivo desde la base de datos
    $this->load->model('archivos_model');
    $archivo = $this->archivos_model->obtener_archivo_por_id($id);

    // Mostrar la información del archivo
    if (!$archivo) {
        // Si el archivo no existe, mostrar un mensaje de error
        $data['error'] = 'El archivo no existe.';
    } else {
        // Si el archivo existe, mostrar su información detallada
        $data['archivo'] = $archivo;

        // Si el archivo es una imagen, mostrar una vista previa
        if (strpos($archivo->tipo, 'image') !== false) {
            $data['vista_previa'] = '<img src="' . base_url('uploads/' . $archivo->nombre) . '" />';
        }
    }

    // Mostrar la vista de visualización de archivos con la información correspondiente
    $this->load->view('archivos/ver', $data);
}




}
