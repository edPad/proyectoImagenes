<div class="container">
    <?php
    //verificamos el id de usuario en sesión y el de la publicación
    if(session()->user === $post['user']){
    ?>    
     <h2>Actualizar usuario</h2>
    <form action="publication/edit" method="post">
        <div class="form-group">
            <input type="hidden" name="id" value="<?= !empty($post['id']) ? $post['id'] : '' ?>">
            <textarea class="form-control" name="content" rows="3" placeholder="Escribe algo"><?= isset($post['content']) ? $post['content'] : '' ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Actualizar usuario</button>
    </form>
    <br>
    <?php
    } else{
        ?>
        <div class="alert alert-danger" role="alert">
            No tienes permiso.
        </div>
    <?php
    }
    ?>
</div>