<?php setlocale(LC_TIME, "esp"); //esto nos ayudara a poner fechas en español ?>
<div class="container">
    <?php
    //Verificar que haya un usuario en sesión de lo contrario no se muestra el formulario
    if(isset(session()->user)) {
        ?>
        <form action="publication/add" method="post">
            <div class="form-group">
                <textarea class="form-control" name="content" rows="3" placeholder="Escribe algo"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Publicar</button>
        </form>
        <br>
    <?php } ?>
    <?php foreach ($posts as $item): //estos son los datos enviados desde el controlador ?>
        <div class="card bg-light mb-3">
            <div class="card-body">
                <strong><?=$item['name']; ?></strong>
                <small><?= strftime("%A, %d de %B de %Y %I:%M", strtotime($item['posted_time'])); ?></small>
                <p class="card-text"><?= $item['content']; ?></p>
                <?php
                //comparamos el id en sesión y el id de la publicación
                //solo el usuario que creo la publicación la  puede modificar o borrar
                if(session()->user === $item['user']){
                ?>
                    <a class="btn btn-primary" href="publication/edit/<?=$item['id']?>" role="button">Editar</a>
                    <a class="btn btn-danger" href="publication/delete/<?=$item['id']?>" role="button">Borrar</a>
                <?php } ?>
            </div>
        </div>
        <?php endforeach; ?>
</div>

<h2>Detalles del archivo</h2>

<?php if (isset($error)): ?>
    <p class="error"><?php echo $error; ?></p>
<?php else: ?>
    <p><strong>Nombre:</strong> <?php echo $archivo->nombre; ?></p>
    <p><strong>Tamaño:</strong> <?php echo $archivo->tamano; ?></p>
    <p><strong>Tipo:</strong> <?php echo $archivo->tipo; ?></p>
    <p><strong>Fecha de carga:</strong> <?php echo $archivo->fecha_carga; ?></p>

    <?php if (isset($vista_previa)): ?>
        <?php echo $vista_previa; ?>
    <?php endif; ?>
<?php endif; ?>





    
